STUDIECENTRUM - klaar om te hosten

1. Zet deze map in een GitHub-repository.
2. Koppel de repository aan je hostingdienst:
   - Render: New > Blueprint > kies de repository. render.yaml regelt alles, ook de schijf.
   - Fly.io, Railway of een andere dienst met Docker: de Dockerfile wordt vanzelf gebruikt. Koppel een blijvende schijf op /data.
   - Een dienst met Node.js zonder Docker: startopdracht "npm start". Koppel een blijvende schijf op /data of /var/data.
3. Klaar. Er zijn geen instellingen of omgevingsvariabelen nodig.

Wat de server zelf regelt
- De poort, het adres en HTTPS-tussenlagen (hij herkent een proxy zelf).
- De plek voor je gegevens: een gekoppelde schijf op /data of /var/data wordt vanzelf gebruikt.
- Geen blijvende schijf gevonden? Dan zie je bovenaan de pagina een waarschuwing en staat het ook in de log van de server.
- Raakt de host je gegevens kwijt (herstart, nieuwe uitrol), dan zet elke pagina die nog open staat ze zelf terug zodra de server weer bereikbaar is.
- Kopieen: hoogstens een per tien minuten, de laatste 60, in de map backups naast data.json.

Goed om te weten
- Er is geen inlog. Iedereen met de link ziet dezelfde gegevens en kan alles aanpassen en verwijderen. Zet er niets gevoeligs in.
- Per onderdeel (notitie, kaart, afspraak, enzovoort) wint de laatste wijziging.
- Dashboard-indeling en een lopende toets blijven per browser.
- Terugzetten uit een kopie: stop de server, kopieer een bestand uit backups naar data.json en start opnieuw. Of gebruik in de app Back-up > Terugzetten.
- Lokaal proberen kan ook: npm start en open http://localhost:8080 (Node.js 18 of nieuwer).

Voor ontwikkelaars: optionele instellingen PORT, HOST, DATA_DIR en TRUST_PROXY=0.
API: GET /api/health, GET /api/changes[?since=N], POST /api/ops met {"ops":[{"c":"notes","id":"abc","item":{...}}]} (zonder item = verwijderen).
Onderdelen: subjects, folders, notes, cards, qs, events, tasks, goals, log, tests.
