'use strict';
const http=require('http'),fs=require('fs'),path=require('path');
const mounted=d=>{try{return fs.statSync(d).dev!==fs.statSync('/').dev}catch(e){return false}},FIND=['/data','/var/data'].find(mounted);
const PORT=+process.env.PORT||8080,HOST=process.env.HOST||'0.0.0.0',DIR=process.env.DATA_DIR||FIND||path.join(__dirname,'data'),FILE=path.join(DIR,'data.json'),BK=path.join(DIR,'backups');
const COLS=['subjects','folders','notes','cards','qs','events','tasks','goals','log','tests'];
fs.mkdirSync(BK,{recursive:true});const DUR=mounted(DIR);
let DB={rev:0,logFrom:0,items:{},log:[]};
try{DB=Object.assign(DB,JSON.parse(fs.readFileSync(FILE,'utf8')))}catch(e){}
COLS.forEach(c=>DB.items[c]=DB.items[c]||{});
let dirty=false,lastBk=0;
function flush(){if(!dirty)return;dirty=false;fs.writeFileSync(FILE+'.tmp',JSON.stringify(DB));fs.renameSync(FILE+'.tmp',FILE);
 if(Date.now()-lastBk>6e5){lastBk=Date.now();fs.copyFileSync(FILE,path.join(BK,'data-'+new Date().toISOString().replace(/[:.]/g,'-')+'.json'));const f=fs.readdirSync(BK).sort();while(f.length>60)fs.unlinkSync(path.join(BK,f.shift()))}}
setInterval(flush,2000).unref();for(const s of['SIGTERM','SIGINT'])process.on(s,()=>{flush();process.exit(0)});
const CSP="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'";
const send=(res,code,o,type,extra)=>{res.writeHead(code,Object.assign({'Content-Type':type||'application/json; charset=utf-8','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Frame-Options':'DENY','Cache-Control':'no-store','Content-Security-Policy':CSP},extra));res.end(type?o:JSON.stringify(o))};
const hits=new Map(),limited=ip=>{const n=Date.now(),h=hits.get(ip)||{c:0,r:n+6e4};if(n>h.r){h.c=0;h.r=n+6e4}h.c++;hits.set(ip,h);return h.c>900};
setInterval(()=>{const n=Date.now();for(const[k,v]of hits)if(n>v.r)hits.delete(k)},6e4).unref();
const fail=(code,msg)=>Object.assign(new Error(msg),{code});
const body=(req,max)=>new Promise((ok,no)=>{let n=0,over=false;const c=[];req.on('data',d=>{if(over)return;n+=d.length;if(n>max){over=true;c.length=0;no(fail(413,'Te groot'))}else c.push(d)});req.on('end',()=>{try{ok(JSON.parse(Buffer.concat(c).toString()||'{}'))}catch(e){no(fail(400,'Ongeldige invoer'))}})});
const STATIC={'/':['index.html','text/html; charset=utf-8'],'/index.html':['index.html','text/html; charset=utf-8'],'/app.js':['app.js','text/javascript; charset=utf-8']};
http.createServer(async(req,res)=>{try{
 const u=new URL(req.url,'http://x'),p=u.pathname,ip=process.env.TRUST_PROXY!=='0'&&req.headers['x-forwarded-for']?String(req.headers['x-forwarded-for']).split(',').pop().trim():req.socket.remoteAddress;
 if(limited(ip))throw fail(429,'Te veel verzoeken');
 if(req.method==='GET'&&STATIC[p])return send(res,200,fs.readFileSync(path.join(__dirname,STATIC[p][0])),STATIC[p][1],{'Cache-Control':'no-cache'});
 if(p==='/api/health'&&req.method==='GET')return send(res,200,{ok:true,rev:DB.rev,durable:DUR});
 if(p==='/api/changes'&&req.method==='GET'){const since=u.searchParams.has('since')?+u.searchParams.get('since'):-1;
  if(!(since>=0)||since>DB.rev||since<DB.logFrom)return send(res,200,{rev:DB.rev,full:true,items:DB.items});
  const last=new Map();for(const e of DB.log)if(e.r>since)last.set(e.c+'/'+e.id,e);
  return send(res,200,{rev:DB.rev,ops:[...last.values()].map(e=>{const it=DB.items[e.c][e.id];return it?{c:e.c,id:e.id,item:it}:{c:e.c,id:e.id,del:1}})})}
 if(p==='/api/ops'&&req.method==='POST'){
  if(!String(req.headers['content-type']||'').startsWith('application/json'))throw fail(415,'Ongeldige invoer');
  const b=await body(req,8e6);if(!Array.isArray(b.ops)||b.ops.length>3000)throw fail(400,'Ongeldige invoer');
  for(const o of b.ops)if(!o||!COLS.includes(o.c)||!/^[a-z0-9][\w-]{0,39}$/i.test(o.id||'')||(o.item!==undefined&&(typeof o.item!=='object'||o.item===null||Array.isArray(o.item))))throw fail(400,'Ongeldige invoer');
  DB.rev++;for(const o of b.ops){if(o.item){o.item.id=o.id;DB.items[o.c][o.id]=o.item}else delete DB.items[o.c][o.id];DB.log.push({r:DB.rev,c:o.c,id:o.id})}
  if(DB.log.length>5000){const d=DB.log.splice(0,DB.log.length-5000);DB.logFrom=d[d.length-1].r}
  dirty=true;return send(res,200,{rev:DB.rev})}
 throw fail(404,'Niet gevonden')}catch(e){send(res,e.code||500,{error:e.code?e.message:'Er ging iets mis'},undefined,e.code===413?{Connection:'close'}:undefined)}}).listen(PORT,HOST,()=>{console.log(`Studiecentrum draait op http://${HOST}:${PORT}`);console.log(`Gegevens: ${DIR}${DUR?'':'  (LET OP: geen blijvende schijf gevonden, gegevens kunnen bij een herstart verdwijnen)'}`)});
